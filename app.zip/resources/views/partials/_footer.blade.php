<hr>

<p class="text-center"> Copyrights Flex - All Rights Reserved </p>
