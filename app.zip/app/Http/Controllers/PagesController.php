<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Post;


class PagesController extends Controller
{
    //uses of a controller
    #process variables data or params
    #talk to the model
    #recieve from the model
    #compile or process data from the model if needed
    #pass that data to the correct view

    public function getIndex(){
      // variable that hold on posts
       $posts = Post::orderBy('created_at', 'desc')->limit(4)->get();
       //return "Home";
       return view('pages.welcome')->withPosts($posts);
    }

    public function getAbout(){
       //return "About me";
       $first = 'FLEX';
       $last = 'HACKER';
       $fullname = $first . " " . $last;
       $email = 'oagilmoemi@gmail.com';
       $data = [
         'email' => $email,
         'fullname' => $fullname,
     ];
       //return view('pages.about')->with("fullname", $fullname);
       return view('pages.about')->withData($data); //using an array
       //return view('pages.about')->withFullname($fullname)->withEmail($email);

    }

    public function getContact(){
       //return "Hello Contact Page";
       return view('pages.contact');
    }
}
