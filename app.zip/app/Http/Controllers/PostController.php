<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Post;
use Session;
use App\Category;


class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //create a variable and store all the blog posts in it from the database
        $posts = Post::orderBy('id', 'desc')->paginate(5); //paginate is to limit stuff displayed in the page

        //return a view and pass in the above variable
        return view('posts.index')->withPosts($posts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //find all the categories
        $categories = Category::all();
        return view('posts.create')->withCategories($categories);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate the data
        $this->validate($request, array(
           'title'        => 'required|max:255',
           'slug'         => 'required|alpha_dash|min:5|max:255|unique:posts,slug',
           'category_id'  => 'required|integer',
           'body'         => 'required',
        ));

        //store in the database
        $post = new Post;
        $post->title       = $request->title;
        $post->slug        = $request->slug;
        $post->category_id = $request->category_id;
        $post->body        = $request->body;

        $post->save();

        Session::flash('success', 'The blog post was successfully saved!'); //('key', 'value')
        //flash exist for one page Request
        //Put exists until the session is removed
        return redirect()->route('posts.show', $post->id);
        //redirect to another page

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $post = Post::find($id);
        return view('posts.show')->withPost($post);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // find the post in the database and save as a variable
        $posts = Post::find($id);

        $categories = Category::all();
        $cats = [];
        foreach ($categories as $category){
            $cats[$category->id] = $category->name;
        }
        // return the view and pass in var we previously created
        return view('posts.edit')->withPost($posts)->withCategories($cats);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         // validate the data
         //grab new Post
         $post = Post::find($id);
         // checking if the slug has changed
         if($request->input('slug') == $post->slug ){
           $this->validate($request, array(
              'title'       => 'required|max:255',
              'category_id' => 'required|integer',
              'body'        => 'required',
         ));
       } else {

        $this->validate($request, array(
           'title'       => 'required|max:255',
           'slug'        => 'required|alpha_dash|min:5|max:255|unique:posts,slug',
           'category_id' => 'required|integer',
           'body'        => 'required',
        ));
         }
        // save the data to the database
        $post = Post::find($id);

        $post->title         = $request->input('title');
        $post->slug          = $request->input('slug');
        $post->category_id   = $request->input('category_id');
        $post->body          = $request->input('body');
        $post->save();

        // set flash with success message
        Session::flash('success', 'This post was successfully saved.');

        // redirect with flash data to posts.show
        return redirect()->route('posts.show', $post->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // find an item that you trying to delete
        $post = Post::find($id);
        $post->delete();
        // set flash with success message
        Session::flash('success', 'This post was successfully deleted.');

        // redirect with flash data to posts.show
        return redirect()->route('posts.index');
    }
}
