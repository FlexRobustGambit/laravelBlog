<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    // when you not following the naming conventions you need to manually tell
    // your model which table it belongs to
    protected $table = 'categories';

    //define the relationship (have many posts)
    public function posts()
    {
      // categorty has many posts
      return $this->hasMany('App\Post');
    }
}
